import React, { useEffect, useState } from "react";
import User from "./User";

function Home({ listOfUsers, deleteUser, setPath }) {
  const [usersList, setUsersList] = useState(listOfUsers);
  useEffect(() => {
    console.log(usersList);
    setUsersList(listOfUsers);
  }, [listOfUsers]);
  useEffect(() => {
    setPath(window.location.href);
  });
  return (
    <div className="homeContainer">
      {usersList.map((userData, index) => (
        <User key={index} userData={userData} deleteUser={deleteUser} />
      ))}
    </div>
  );
}

export default Home;
